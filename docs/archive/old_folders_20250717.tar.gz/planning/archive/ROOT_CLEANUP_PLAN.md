# 📋 Root Directory Cleanup Plan - DefinitieAgent

## 📊 Overzicht

De root directory bevat momenteel 30+ losse documenten die beter georganiseerd kunnen worden. Dit plan categoriseert alle files en geeft duidelijke acties.

## 🗂️ Categorieën & Acties

### 🟢 **1. Project Essentials (BEHOUDEN in root)**
Deze files horen in de root voor zichtbaarheid:

| File | Status | Reden |
|------|--------|-------|
| README.md | ✅ Behouden | Project overview |
| SETUP.md | ✅ Behouden | Quick start guide |
| CONTRIBUTING.md | ✅ Behouden | Dev guidelines |
| CLAUDE.md | ✅ Behouden | AI coding standards |
| requirements.txt | ✅ Behouden | Python dependencies |
| .env.example | ✅ Behouden | Config template |

### 🟡 **2. Test Files (VERPLAATSEN naar tests/)**
```
test_*.py files in root:
- test_direct_rate_limiter.py      → tests/rate_limiting/
- test_endpoint_rate_limiting.py   → tests/rate_limiting/
- test_metadata_fields.py          → tests/functionality/
- test_ontologie.py               → tests/unit/
- test_rate_limit_config.py       → tests/rate_limiting/
- test_services_consolidation.py  → tests/services/
- test_ui_scores.py               → tests/ui/
- test_voorbeelden.py             → tests/unit/
- test_voorbeelden_clean.py       → tests/unit/
```

### 🟡 **3. Analysis & Planning Docs (VERPLAATSEN naar docs/)**
```
Status & Planning documenten:
- CODEBASE_CLEANUP_STATUS.md         → docs/status/
- CODEBASE_REVIEW_STAPPENPLAN.md     → docs/analysis/
- DUPLICATE_CODE_ANALYSIS.md         → docs/analysis/
- LEGACY_CLEANUP_PLAN.md             → docs/planning/
- LEGACY_FEATURE_IMPLEMENTATION_PLAN.md → docs/planning/
- LEGACY_FEATURE_PRIORITY_LIST.md    → docs/planning/
- LEGACY_VOORBEELDEN_ANALYSIS.md     → docs/analysis/
- SERVICES_CONSOLIDATION_LOG.md      → docs/status/
- STREAMLIT_APP_TEST_SUMMARY.md      → docs/testing/
- DEFINITIEAGENT_CODEBASE_ANALYSIS_2025.md → docs/analysis/
```

### 🟡 **4. Documentation Plans (VERPLAATSEN/ARCHIVEREN)**
```
Recent gemaakt tijdens cleanup:
- DOCUMENTATIE_OPSCHOON_PLAN.md     → docs/planning/archive/
- ROOT_CLEANUP_PLAN.md (dit bestand) → docs/planning/archive/
```

### 🔴 **5. Browser Test Files (VERWIJDEREN of ARCHIVEREN)**
```
Oude test documenten:
- Browser Test Checklist.docx       → VERWIJDEREN
- Browser Test Checklist.html       → VERWIJDEREN  
- Browser Test Checklist.fld/       → VERWIJDEREN (hele folder)
- ~$owser Test Checklist.html       → VERWIJDEREN (temp file)
```

### 🔴 **6. Database Files (TOEVOEGEN aan .gitignore)**
```
SQLite temporary files:
- definities.db-shm                 → .gitignore
- definities.db-wal                 → .gitignore
- test.db-shm                       → .gitignore
- test.db-wal                       → .gitignore
```

### 🟢 **7. Version Control (BEHOUDEN/UPDATE)**
```
- CHANGELOG.md                      → BEHOUDEN (maar updaten!)
- .gitignore                        → UPDATE met db files
```

### 🟡 **8. Archive/Backup Folders (REVIEW)**
```
- archive/                          → Check inhoud, mogelijk consolideren
- backups/                          → Check inhoud, mogelijk naar data/backups/
- docs_backup_*.tar.gz              → Naar backups/ folder
```

## 📁 Voorgestelde Nieuwe Structuur

```
definitie-app/
├── README.md                       ✅ (update nodig)
├── SETUP.md                        ✅ 
├── CONTRIBUTING.md                 ✅
├── CHANGELOG.md                    ✅ (update nodig)
├── CLAUDE.md                       ✅
├── requirements.txt                ✅
├── .env.example                    ✅
├── .gitignore                      📝 (update)
├── src/                           (ongewijzigd)
├── tests/                         (+ nieuwe test files)
├── docs/
│   ├── analysis/                  (+ analysis docs)
│   ├── planning/                  (+ planning docs)
│   ├── status/                    (+ status docs)
│   └── testing/                   (+ test summaries)
├── data/                          (ongewijzigd)
├── backups/                       (consolideer alle backups)
└── [andere project folders]
```

## 🎯 Actie Volgorde

### Fase 1: Voorbereiding (5 min)
1. ✅ Backup is al gemaakt
2. Creëer nieuwe folders in docs/

### Fase 2: Test Files (10 min)
1. Verplaats alle test_*.py files naar juiste test subfolder
2. Update imports indien nodig

### Fase 3: Documentatie (15 min)
1. Verplaats analysis docs naar docs/analysis/
2. Verplaats planning docs naar docs/planning/
3. Verplaats status docs naar docs/status/

### Fase 4: Cleanup (10 min)
1. Verwijder Browser Test files
2. Update .gitignore met database patterns
3. Consolideer backup folders

### Fase 5: Verificatie (5 min)
1. Check dat root alleen essentials bevat
2. Update CHANGELOG.md
3. Git status check

## ⚠️ Belangrijke Overwegingen

1. **Archive folders**: Eerst checken wat erin zit voordat verwijderen
2. **Test files**: Mogelijk moeten imports aangepast worden
3. **Git history**: Gebruik `git mv` voor het verplaatsen om history te behouden
4. **CI/CD**: Check of scripts nog naar juiste locaties verwijzen

## ❓ Beslispunten

1. **Archive folder** in root - wat zit erin? Behouden of consolideren?
2. **Backups folder** - alles hierheen of naar data/backups/?
3. **CHANGELOG.md** - direct updaten of later?
4. **Test files** - eerst testen of ze nog werken na verplaatsing?

## 🚀 Volgende Stap

Na goedkeuring van dit plan:
1. Nieuwe folder structuur aanmaken
2. Files verplaatsen volgens plan
3. .gitignore updaten
4. Verificatie run

**Totale geschatte tijd: 45 minuten**