# 📋 Documentatie Opschoon Plan - DefinitieAgent

## 🔒 Stap 1: BACKUP STRATEGIE

### Backup Commando's
```bash
# Optie 1: Volledige docs backup (aanbevolen)
cd /Users/chrislehnen/Projecten/Definitie-app
tar -czf docs_backup_$(date +%Y%m%d_%H%M%S).tar.gz docs/ *.md

# Optie 2: Git-based backup (als alles gecommit is)
git checkout -b backup/docs-before-cleanup-$(date +%Y%m%d)
git add -A && git commit -m "Backup: Documentatie voor opschoning"

# Optie 3: Simpele folder copy
cp -r docs/ docs_backup_$(date +%Y%m%d)/
```

## 📁 Stap 2: ANALYSE PER FOLDER

### 🟢 **Root Directory Files**

| Bestand | Status | Actie | Reden |
|---------|--------|-------|-------|
| README.md | ⚠️ Deels verouderd | UPDATE | Features lijst klopt niet met realiteit |
| CLAUDE.md | ✅ Actueel | BEHOUDEN | Goede coding standards |
| .DS_Store | 🗑️ | VERWIJDEREN | MacOS system file |
| requirements*.txt | ✅ Actueel | BEHOUDEN | Dependencies |

**Nieuw toe te voegen:**
- `.env.example` - Template voor environment setup
- `CONTRIBUTING.md` - Development guidelines
- `SETUP.md` - Quick start guide

### 🟡 **docs/ (Main Folder)**

| Bestand | Laatste Update | Status | Actie | Reden |
|---------|---------------|--------|-------|-------|
| ai-agents-design.md | Dec 16 | ⚠️ Verouderd | ARCHIVEREN | Oude architectuur info |
| brownfield-architecture.md | Vandaag | ✅ Actueel | BEHOUDEN | Net gemaakt, zeer waardevol |
| DEFINITIEAGENT_CODEBASE_ANALYSIS_2025.md | Vandaag | ✅ Actueel | BEHOUDEN | Recente grondige analyse |
| nieuwe_versie_roadmap_v2.md | Dec 21 | ⚠️ Onduidelijk | REVIEW | Check overlap met andere roadmaps |

### 🔴 **docs/archive/**

**Actie: VOLLEDIG VERWIJDEREN**
- Bevat 15+ oude versies van requirements
- Geen actuele waarde
- Verwarrend bij zoeken

### 🔴 **docs/oude-requirements/**

**Actie: VOLLEDIG VERWIJDEREN**
- Duplicaat van archive folder
- Verouderde requirements docs

### 🟡 **docs/requirements/**

| Bestand | Status | Actie | Reden |
|---------|--------|-------|-------|
| roadmap-*.md (6 versies) | 🔄 | CONSOLIDEREN | Te veel versies, maak 1 actuele |
| validation-architecture.md | ✅ | BEHOUDEN | Goede tech spec |
| requirements-*.md | ⚠️ | REVIEW | Check welke nog relevant zijn |

### 🟢 **docs/development/architecture/**

**Actie: VOLLEDIG BEHOUDEN**
- Waardevolle PlantUML diagrammen
- Goede visualisaties
- Up-to-date met huidige architectuur

### 🔴 **docs/development/archive/**

**Actie: VOLLEDIG VERWIJDEREN**
- Weer een archive folder
- Oude tech analyses

### 🟡 **docs/development/roadmap/**

**GROOTSTE PROBLEEM: 23 bestanden!**

Voorstel voor consolidatie:
1. `roadmap_week_*.md` (10 files) → Consolideer naar 1 actuele roadmap
2. `todo_*.md` (8 files) → Verwijderen, gebruik issue tracker
3. `*_plan.md` (5 files) → Selecteer meest recente, rest archiveren

### 🟢 **docs/development/technical/**

**Actie: BEHOUDEN & UPDATEN**
- API documentatie is goed
- Tech specs zijn waardevol
- Enkele files mogelijk updaten

### 🟡 **docs/development/toetsregels/**

**Actie: REVIEW**
- Check overlap met `src/ai_toetsing/toetsregels_v3.json`
- Mogelijk consolideren of verwijderen

## 📐 Stap 3: NIEUWE STRUCTUUR VOORSTEL

```
definitie-app/
├── README.md                    # UPDATE: Accurate project overview
├── SETUP.md                     # NIEUW: Quick start guide
├── CONTRIBUTING.md              # NIEUW: Development guidelines  
├── CHANGELOG.md                 # NIEUW: Version history
├── .env.example                 # NIEUW: Environment template
├── CLAUDE.md                    # BEHOUD: AI coding standards
└── docs/
    ├── README.md               # NIEUW: Docs overview & index
    ├── architecture/           
    │   ├── brownfield-architecture.md  # Recent & actueel
    │   ├── diagrams/          # PlantUML diagrams
    │   └── decisions/         # ADRs (Architecture Decision Records)
    ├── api/                   
    │   ├── endpoints.md       # API documentatie
    │   └── examples/          # Request/response examples
    ├── development/           
    │   ├── roadmap.md         # GECONSOLIDEERD uit 23 files
    │   ├── technical-specs/   # Belangrijke tech docs
    │   └── validation-rules/  # Toetsregels documentatie
    └── guides/                # NIEUW
        ├── user-guide.md      # Voor eindgebruikers
        └── admin-guide.md     # Voor beheerders

## 🗑️ Te verwijderen folders (na backup):
- docs/archive/
- docs/oude-requirements/
- docs/development/archive/
- Alle .DS_Store files
```

## 🎯 Stap 4: PRIORITEIT ACTIES

### Week 1: Basis Opschoning
1. **Backup maken** (30 min)
2. **Verwijder archive folders** (15 min)
3. **Consolideer roadmaps** → 1 actuele versie (2 uur)
4. **Update README.md** met accurate info (1 uur)

### Week 2: Nieuwe Structuur
1. **Creëer ontbrekende files** (.env.example, SETUP.md)
2. **Reorganiseer remaining docs** volgens nieuwe structuur
3. **Update alle interne links**

### Week 3: Documentatie Verbetering
1. **Schrijf user guides**
2. **Update API documentatie**
3. **Voeg examples toe**

## ❓ Beslispunten voor jou:

1. **Backup methode**: Welke van de 3 opties?
2. **Roadmap consolidatie**: Zal ik de 23 files analyseren en 1 versie voorstellen?
3. **Requirements files**: Wil je die allemaal weg of eerst reviewen?
4. **Nieuwe guides**: Direct maken of later?

## 🚀 Volgende Stap:

Als je akkoord bent met dit plan:
1. Eerst backup maken
2. Dan beginnen met de "Te verwijderen" folders
3. Daarna consolidatie van roadmaps
4. Tot slot nieuwe structuur implementeren

**Wat wil je eerst aanpakken?**