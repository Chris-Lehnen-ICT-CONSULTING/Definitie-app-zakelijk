#!/usr/bin/env python3
"""Test wat de Streamlit app precies returned."""

import subprocess
import time
import requests
import sys

# Start de app
print("🚀 Starting Streamlit app...")
process = subprocess.Popen(
    ["streamlit", "run", "src/main.py", "--server.headless", "true", "--server.port", "8506"],
    stdout=subprocess.PIPE,
    stderr=subprocess.STDOUT,
    text=True
)

# Wacht en capture output
time.sleep(8)

# Lees subprocess output
output_lines = []
for i in range(20):  # Lees max 20 regels
    line = process.stdout.readline()
    if line:
        output_lines.append(line.strip())

print("\n📋 App Output:")
for line in output_lines[:10]:  # Toon eerste 10 regels
    print(f"   {line}")

# Test HTTP response
try:
    response = requests.get("http://localhost:8506", timeout=5)
    print(f"\n🌐 HTTP Status: {response.status_code}")
    print(f"📏 Response Size: {len(response.text)} bytes")
    
    # Toon begin van response
    print("\n📄 Response Content (first 500 chars):")
    print(response.text[:500])
    
    # Check voor JavaScript/HTML
    if "<html" in response.text:
        print("\n✅ HTML content gevonden")
    if "streamlit" in response.text.lower():
        print("✅ Streamlit references gevonden")
        
except Exception as e:
    print(f"\n❌ HTTP Request failed: {e}")

# Check stderr voor errors
stderr_output = []
while True:
    line = process.stdout.readline()
    if not line:
        break
    stderr_output.append(line.strip())
    if len(stderr_output) > 10:
        break

if stderr_output:
    print("\n⚠️  Mogelijke errors:")
    for line in stderr_output[:5]:
        print(f"   {line}")

# Stop de app
process.terminate()
process.wait(timeout=5)
print("\n✅ App gestopt")