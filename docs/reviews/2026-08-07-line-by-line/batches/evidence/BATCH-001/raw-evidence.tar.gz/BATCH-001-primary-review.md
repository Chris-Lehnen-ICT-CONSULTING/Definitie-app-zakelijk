# BATCH-001 primary review

Reviewer: `codex-root`

## Dekkingsbewijs

- 8/8 blobs gelezen uit de immutable base object-ID's;
- 2.581/2.581 fysieke regels line-by-line gelezen;
- 119/119 symbolen beoordeeld;
- voor ieder symbool is een `git grep`-referentiezoekactie tegen de base-tree
  uitgevoerd; matrix: `BATCH-001-references.tsv`;
- alle imports, foutpaden, resources, concurrency, logging en relevante tests
  van de pilot zijn gevolgd;
- geen applicatiebestand gewijzigd.

## Testbewijs

1. Zonder credentials, buiten de sandbox: 26 pass, 2 fail. Failures:
   `test_service_container_initializes` en
   `test_service_factory_returns_same_instance`, beide door ontbrekende
   Anthropic-key.
2. Met alleen dummy Anthropic-key: 27 pass, 1 fail; de resterende smoke-test
   initialiseert ook de OpenAI-embeddingclient.
3. Met `OPENAI_API_KEY=test` en `ANTHROPIC_API_KEY=test`: 28/28 pass, zonder
   externe API-aanroep.
4. De groene run rapporteert nog 18 `ResourceWarning`-meldingen en drie
   `DeprecationWarning`-locaties.

## Bevindingen

### PILOT-001 — P1 — proven — concurrency/data-integriteit

- Pad/regels: `src/database/db_connection.py:27-94`.
- Bewijs: één cached `sqlite3.Connection` wordt met
  `check_same_thread=False` gedeeld. `transaction()` behandelt iedere reeds
  actieve transactie als nesting en gebruikt geen thread-/requestidentiteit of
  lock. De repository is bovendien een processingleton en
  `get_tabbed_interface()` gebruikt de globale `st.cache_resource`-scope; de
  geïnstalleerde Streamlit-docstring zegt expliciet dat zulke resources over
  alle users/sessions worden gedeeld en thread-safe moeten zijn.
- Reproductie: start twee threads op dezelfde `DatabaseConnection`. Thread 1
  opent een transactie en wacht; thread 2 opent `transaction()`, schrijft en
  keert succesvol terug; thread 1 rolt daarna terug. Waargenomen resultaat:
  `thread-2-returned-success`, maar `persisted_rows=[]` — de succesvolle write
  van thread 2 is door de transactie van thread 1 teruggerold.
- Oplossing: deel nooit één connection over requests; gebruik een connection
  per transactie/thread (of pool/thread-local), expliciete serialisatie van
  writes en savepoints/rollback-only-semantiek. Voeg een deterministische
  parallelle regressietest toe.

### PILOT-002 — P1 — proven — audittrail

- Pad/regels: `src/ui/components/definition_generator_tab.py:662-689`.
- Bewijs: iedere reviewsubmission gebruikt hardcoded `user="web_user"`; de
  echte actor wordt niet uit sessie/auth/context gelezen, terwijl de UI daarna
  `result.updated_by` als auditinformatie logt.
- Reproductie: laat twee verschillende gebruikers een definitie voor review
  indienen; beide workflowevents krijgen dezelfde actor `web_user`.
- Oplossing: bepaal de actor server-side uit een geauthenticeerde identiteit en
  geef een onveranderlijk user-ID door. Als anonieme bediening bewust is, gebruik
  een expliciete `anonymous`-actor plus sessie/correlation-ID.

### PILOT-003 — P2 — proven — foutafhandeling/schema

- Pad/regels: `src/database/db_connection.py:107-156`.
- Bewijs: `sqlite3.Error` uit `executescript()` wordt alleen als warning gelogd;
  `init_database()` retourneert normaal. Als `schema.sql` ontbreekt, wordt een
  beperkte fallback met alleen `definities` gemaakt, terwijl de rest van de app
  meer tabellen verwacht.
- Reproductie: laat een gemockte connection bij `executescript` de fout
  `schema broken` geven. Waargenomen: warning, `returned None`, geen exception.
- Oplossing: behandel schema-/migratiefouten als startup/readinessfailure, voer
  migraties atomisch uit en verwijder of versioneer de onvolledige fallback.

### PILOT-004 — P2 — proven — eager credentialinitialisatie

- Pad/regels: `src/services/service_factory.py:120-129,767-790` en
  `tests/smoke/test_critical_paths.py:24-34`.
- Bewijs: `ServiceAdapter.__init__` bouwt direct orchestrator en web lookup;
  orchestrator bouwt AI- en RAG-clients. Zonder keys falen twee pilot-tests; met
  alleen Anthropic-key blijft de OpenAI embeddingclient falen; met twee dummy
  initwaarden slagen 28/28 tests.
- Reproductie: unset beide API-keys en roep `get_definition_service()` of
  `ServiceContainer().generator()` aan.
- Oplossing: initialiseer providerclients lazy bij de eerste echte AI/RAG-call,
  injecteer testclients/config en laat smoke-tests ontbrekende optionele
  providers expliciet mocken of skippen.

### PILOT-005 — P2 — proven — boolean-normalisatie

- Pad/regels: `src/services/service_factory.py:251-315`.
- Bewijs: legacy/objectdata is als `Any` geaccepteerd, maar `bool(value)` wordt
  gebruikt. Directe reproductie geeft voor `is_valid="false"` en `"0"` beide
  `is_acceptable=True`.
- Reproductie: `object.__new__(ServiceAdapter).normalize_validation({"score":
  0.0, "is_valid": "false"})`.
- Oplossing: accepteer uitsluitend echte booleans of parse een kleine expliciete
  stringenum (`true/false`, `1/0`) en verwerp overige waarden.

### PILOT-006 — P2 — proven — testisolatie/lokale data

- Pad/regels: `tests/smoke/test_critical_paths.py:40-49,96-106,136-146`.
- Bewijs: drie smoke-tests construeren `DefinitieRepository()` zonder temp-pad;
  daarmee openen/initialiseren zij `data/definities.db` in de actieve worktree.
  De pilotrun liet daar een genegeerde SQLitefile van 249.856 bytes achter.
- Reproductie: start vanuit een schone worktree `pytest
  tests/smoke/test_critical_paths.py`; inspecteer daarna `data/definities.db`.
- Oplossing: gebruik `tmp_path`/fixtures en fail in testmode als het default
  ontwikkelpad wordt benaderd.

### PILOT-007 — P2 — suspected — prompt/context disclosure

- Pad/regels: `src/ui/components/definition_generator_tab.py:457-503`.
- Bewijs: de promptdebugcomponent wordt voor ieder resultaat zonder rol- of
  environmentgate gerenderd. De gevolgde callee toont en laat de exacte prompt
  downloaden, inclusief contextmetadata.
- Reproductie: nog niet live getest; genereer een definitie met gevoelige
  documentcontext en open `Debug: Gebruikte Prompts`.
- Oplossing: schakel dit in productie uit of beperk tot een geautoriseerde
  debugrol; redacteer context en maak downloads auditbaar.

### PILOT-008 — P2 — suspected — privacy in logging

- Pad/regels: `src/ui/components/definition_generator_tab.py:627-647`.
- Bewijs: bij opschoning worden de eerste 100 tekens van originele en
  opgeschoonde definitie letterlijk naar debuglogs geschreven. Definitietekst
  kan uit gebruikers-/documentcontext komen.
- Reproductie: nog niet met persoonsdata uitgevoerd; zet debuglogging aan en
  genereer een definitie die wordt opgeschoond.
- Oplossing: log alleen generation-ID, lengtes en een niet-omkeerbare digest;
  geen inhoudelijke gebruiker-/documenttekst.

### PILOT-009 — P2 — proven — informatielek via foutmelding

- Pad/regels: `src/ui/components/definition_generator_tab.py:662-717`.
- Bewijs: workflow- en exportexceptions worden met `{e!s}` direct via
  `st.error` aan de gebruiker getoond; dezelfde details horen uitsluitend in
  serverlogs.
- Reproductie: laat workflow/export een exception met een pad, SQL-fragment of
  providerdetail gooien; de tekst verschijnt ongewijzigd in de UI.
- Oplossing: toon generieke Nederlandse microcopy met correlation-ID; log de
  exception server-side met stacktrace en veilige metadata.

### PILOT-010 — P2 — suspected — performanceblindspot

- Pad/regels: `src/main.py:120-150,189-276`.
- Bewijs: elke renderduur >5 seconden wordt uitsluitend op timing als “heavy
  operation” geclassificeerd. Alleen niet-heavy renders doorlopen
  `check_regression`; een werkelijk vastgelopen UI-render van 5,1 s omzeilt dus
  waarschuwing en wordt als normale heavy operation gelogd.
- Reproductie: geef `_track_streamlit_metrics` een `render_ms` >5000 met een
  gemockte tracker; `check_regression` wordt niet aangeroepen.
- Oplossing: instrumenteer expliciete operationtypes/spans en houd daarnaast
  een absolute UI-watchdog; gebruik timing niet als enige classificatiesignaal.

### PILOT-011 — P2 — proven — resource lifecycle

- Pad/regels: `src/database/db_connection.py:23-49`.
- Bewijs: de connectionprovider heeft geen `close()`-/shutdownpad en vervangt
  een ongeldige cached connection zonder lifecyclecleanup. De groene pilotrun
  rapporteert 18 `ResourceWarning`-meldingen voor ongeclosed SQLiteconnections.
- Reproductie: draai de 28 pilot-tests met beide dummy keys en warnings actief.
- Oplossing: introduceer expliciet context-/shutdownbeheer, sluit repository-
  singletons bij cache eviction/testteardown en voeg `ResourceWarning` als
  regressiegate toe.

### PILOT-012 — P3 — proven — testkwaliteit

- Pad/regels: `tests/smoke/test_critical_paths.py:1-7,53-63,149-170`.
- Bewijs: header claimt 10 tests en “80% confidence”, maar er zijn 9 testfuncties;
  `test_validation_rules_load` bevat geen assertion en meerdere tests bewijzen
  alleen dat een object niet `None` is. Credential- en DB-isolatie ontbreken.
- Reproductie: tel de verzamelde testfuncties en inspecteer de assertionloze
  validatietest.
- Oplossing: definieer concrete smoke-acceptatiecriteria, assert het verwachte
  aantal/IDs van regels en functioneel gedrag, en maak alle fixtures hermetisch.

### PILOT-013 — P3 — proven — migratieresten/onderhoudbaarheid

- Pad/regels: `src/services/service_factory.py:32-108,714-764` en
  `src/ui/components/definition_generator_tab.py:719-723`.
- Bewijs: `_freeze_config` heeft geen externe referentie;
  `LegacyGenerationResult` wordt alleen door tests gebruikt; de sync
  `ServiceFactory`-API gooit structureel `NotImplementedError`; `_clear_results`
  heeft geen caller. De adapter combineert serialisatie, generatie, export en
  weblookup in één 790-regels module.
- Reproductie: `git grep` tegen de immutable base-tree; zie referentiematrix.
- Oplossing: verwijder bewezen ongebruikte shims in een aparte migratie, splits
  mapping/export/generationseams en leg één publiek servicecontract vast.

## Niet getest

- Geen echte AI-call of productiecredential gebruikt.
- Promptdisclosure en responsive/a11y-gedrag zijn niet live in een browser
  getest in deze pilot; dat gebeurt in de latere functionele/UI-batches.
- Geen muterende gebruikersflow op de echte database uitgevoerd.
