# DefinitieAgent Brownfield Enhancement PRD

## Introduction

This document outlines the architectural approach for enhancing DefinitieAgent with complete legacy feature parity in the new modular structure. Its primary goal is to serve as the guiding blueprint for AI-driven development to restore all legacy functionality while ensuring seamless integration with the existing system.

**Relationship to Existing Architecture:**
This document supplements existing project architecture by defining how legacy features will be restored and UI completeness achieved. It respects the "Features First" philosophy where legacy code serves as the specification.

### Change Log

| Change | Date | Version | Description | Author |
|--------|------|---------|-------------|--------|
| Initial Draft | 2025-07-17 | 1.0 | Complete PRD with architecture analysis | BMad Orchestrator |

## Intro Project Analysis and Context

### Existing Project Overview

#### Analysis Source
- Document-project output available at: `/Users/chrislehnen/Projecten/Definitie-app/docs/brownfield-architecture.md`
- Comprehensive codebase analysis completed
- All project documentation reviewed and consolidated

#### Current Project State
Het DefinitieAgent project is een AI-powered Nederlandse definitie generator voor juridische en overheidscontexten. Het systeem gebruikt GPT-4 om definities te genereren die voldoen aan 46 kwaliteitsregels. De applicatie heeft succesvol een services consolidatie ondergaan (3→1 UnifiedDefinitionService) maar mist nog 70% van de legacy UI functionaliteit en heeft een grotendeels broken test suite (87% failing).

### Available Documentation Analysis

#### Available Documentation
Document-project analysis available - using existing technical documentation

Key documents available:
- ✓ Tech Stack Documentation 
- ✓ Source Tree/Architecture 
- ✓ Coding Standards (partial - CLAUDE.md)
- ✓ API Documentation 
- ✓ External API Documentation 
- ✓ UX/UI Guidelines 
- ✓ Technical Debt Documentation 
- ✓ Migration roadmap, quick wins lijst

### Enhancement Scope Definition

#### Enhancement Type
- ✓ Major Feature Modification
- ✓ UI/UX Overhaul
- ✓ Bug Fix and Stability Improvements

#### Enhancement Description
Het volledig operationeel maken van alle legacy functionaliteiten in de nieuwe modulaire structuur. Dit omvat het herstellen van ontbrekende UI componenten (70%), implementeren van content enrichment features, en het repareren van de test suite om een stabiele ontwikkelomgeving te garanderen.

#### Impact Assessment
- ✓ Major Impact (architectural changes required)

### Goals and Background Context

#### Goals
- Alle legacy features werkend maken in nieuwe modulaire architectuur
- 10 Streamlit UI tabs volledig functioneel maken (nu 30%)
- Content enrichment services implementeren (synoniemen, antoniemen, toelichting)
- Test suite repareren van 87% broken naar minimaal 60% coverage
- Quick wins implementeren voor directe gebruikerswaarde

#### Background Context
Na een succesvolle services consolidatie naar UnifiedDefinitionService mist de applicatie nog kritieke legacy functionaliteit. De "Features First" aanpak heeft geresulteerd in werkende kernfunctionaliteit maar incomplete UI en ontbrekende features. Met de solide modulaire basis is het nu tijd om alle legacy features te herstellen en het systeem productie-klaar te maken.

## Requirements

### Functional Requirements

- **FR1**: Alle 10 Streamlit UI tabs moeten volledig functioneel zijn (nu 3/10)
- **FR2**: Legacy content enrichment features moeten werken in nieuwe architectuur (synoniemen, antoniemen, toelichting)
- **FR3**: Prompt viewer met copy functionaliteit moet beschikbaar zijn
- **FR4**: Metadata velden moeten geactiveerd worden (code bestaat al)
- **FR5**: Export functionaliteit voor plain text, Excel, en PDF
- **FR6**: Ontologische score visualisatie moet zichtbaar zijn in UI
- **FR7**: Developer tools tab met logging toggle functionaliteit
- **FR8**: Aangepaste definitie editing mogelijkheid

### Non-Functional Requirements

- **NFR1**: Response tijd < 5 seconden (nu 8-12 sec)
- **NFR2**: Prompt grootte < 10k karakters (nu 35k)
- **NFR3**: Test coverage minimaal 60% (nu 14-40%)
- **NFR4**: Database concurrent access zonder locks
- **NFR5**: UTF-8 encoding correct in web lookup
- **NFR6**: Manual test protocol documentatie compleet

### Compatibility Requirements

- **CR1**: Bestaande database schema blijft compatible
- **CR2**: Legacy API endpoints blijven werken via wrappers
- **CR3**: UI componenten volgen Streamlit patterns
- **CR4**: Import structuur gestandaardiseerd (geen 3 verschillende stijlen)

## User Interface Enhancement Goals

### Integration with Existing UI

De nieuwe UI componenten moeten naadloos integreren met het bestaande Streamlit framework:

- **Streamlit Session State**: Alle nieuwe componenten gebruiken session state voor data persistence
- **Widget Key Management**: Fix de widget key generator bug voor stabiele UI
- **Consistent Styling**: Volg bestaande Streamlit theming en layout patterns
- **Tab Navigation**: Behoud de 10-tab structuur maar maak ze functioneel

### Modified/New Screens and Views

**Te activeren tabs:**
1. **Prompt Viewer Tab** - Toon gebruikte prompts met copy functie
2. **Aangepaste Definitie Tab** - Editor voor definitie aanpassing
3. **Developer Tools Tab** - Logging viewer en debug opties
4. **Expert Review Tab** - Review workflow implementatie
5. **Externe Bronnen Tab** - Document upload verbetering
6. **Orchestratie Tab** - Multi-agent coordinatie view
7. **Management Tab** - Systeem configuratie UI

### UI Consistency Requirements

- Alle tabs moeten dezelfde layout structuur volgen
- Error handling via st.error() consistentie
- Loading states via st.spinner() voor alle async operations
- Success feedback via st.success() na acties
- Help tooltips bij complexe features

## Technical Architecture Analysis

### Current Architecture (AS-IS)

#### System Overview
Het DefinitieAgent systeem heeft recent een succesvolle consolidatie ondergaan maar bevindt zich nog in een hybride staat tussen legacy en modern architectuur.

#### Core Components

**1. Service Layer** ✅ **GECONSOLIDEERD**
```
UnifiedDefinitionService (Singleton)
├── Sync/Async processing support
├── Legacy compatibility wrappers
├── AUTO/MODERN/LEGACY/HYBRID modes
└── Centralized business logic
```

**2. AI & Validation Layer** ⚠️ **PARTIALLY MIGRATED**
```
├── ai_toetsing/
│   ├── 46 JSON validators ✅
│   ├── Python validator implementations ✅
│   └── Orchestration service ✅
├── ai_agents/ (BROKEN)
│   └── Content enrichment missing ❌
```

**3. UI Layer** 🔴 **30% FUNCTIONAL**
```
10 Streamlit Tabs:
├── ✅ Definitie Generatie (basic)
├── ✅ Geschiedenis
├── ✅ Export (basic)
├── ⚠️ Kwaliteitscontrole (partial)
├── ❌ Prompt Viewer
├── ❌ Aangepaste Definitie
├── ❌ Developer Tools
└── ❌ 3 andere tabs
```

**4. Data Layer** ✅ **MODERN**
```
├── SQLAlchemy ORM
├── Repository Pattern
├── SQLite Database
└── Migration support
```

#### Current Technical Debt

1. **Import Path Chaos**: 3 verschillende import stijlen
2. **Config Fragmentation**: 4 config systemen zonder centrale authority
3. **Test Suite**: 87% tests broken
4. **Performance**: 8-12 sec response tijd, 35k prompt size
5. **Encoding Issues**: UTF-8 problemen in web lookup

### Target Architecture (TO-BE)

#### System Goals
- 100% UI functionaliteit
- Alle legacy features werkend
- <5 sec response tijd
- 60%+ test coverage
- Gestandaardiseerde architectuur

#### Enhanced Components

**1. Service Layer** (Minor Updates)
```
UnifiedDefinitionService
├── Content Enrichment Integration ➕
├── Performance Optimizations ➕
├── Simplified Prompt Builder ➕
└── Enhanced Caching ➕
```

**2. New Content Services** 🆕
```
ContentEnrichmentService
├── Synoniemen Generator
├── Antoniemen Generator
├── Toelichting Generator
└── Legacy Feature Parity
```

**3. Complete UI Layer** 🎯
```
All 10 Tabs Functional:
├── Enhanced Definitie Generatie
│   ├── Prompt Viewer Component
│   ├── Metadata Fields
│   └── Copy Functionality
├── Aangepaste Definitie Editor
├── Developer Console
└── All Other Tabs Activated
```

### Gap Analysis

| Component | Current State | Target State | Gap | Effort |
|-----------|--------------|--------------|-----|--------|
| Services | Consolidated ✅ | + Enrichment | Content features | 1 week |
| UI Tabs | 30% working | 100% working | 7 tabs | 2 weeks |
| Testing | 87% broken | 60% coverage | Fix + new tests | 1 week |
| Performance | 8-12 sec | <5 sec | Optimization | 1 week |
| Config | 4 systems | 1 unified | Consolidation | 3 days |

### Migration Strategy

#### Phase 1: Quick Wins (Week 1)
1. Fix database concurrent access
2. Resolve UTF-8 encoding
3. Activate metadata fields
4. Add prompt viewer

#### Phase 2: Feature Restoration (Week 2-3)
1. Implement ContentEnrichmentService
2. Port legacy enrichment logic
3. Activate remaining UI tabs
4. Add definition editor

#### Phase 3: Quality & Performance (Week 4-5)
1. Fix import standardization
2. Unify config systems
3. Optimize prompts (35k→10k)
4. Implement caching strategy

#### Phase 4: Testing & Stability (Week 6)
1. Repair test suite
2. Add integration tests
3. Document manual test scenarios
4. Performance profiling

## Technical Constraints and Integration Requirements

### Existing Technology Stack

**Languages**: Python 3.8+
**Frameworks**: Streamlit 1.29.0, FastAPI (optional)
**Database**: SQLite via SQLAlchemy 2.0.25
**Infrastructure**: Local deployment, geen cloud
**External Dependencies**: OpenAI API 1.12.0, httpx 0.26.0, Pydantic 2.5.3

### Integration Approach

**Database Integration Strategy**: 
- Behoud huidige SQLAlchemy models
- Voeg indexes toe voor performance
- Implementeer connection pooling voor concurrent access

**API Integration Strategy**: 
- OpenAI calls via centralized AI service
- Rate limiting via smart_rate_limiter
- Retry logic met exponential backoff

**Frontend Integration Strategy**: 
- Nieuwe UI componenten als separate Python modules
- Integratie via tab registry in main app
- Session state management voor cross-tab data

**Testing Integration Strategy**: 
- Fix import paths eerst
- Voeg pytest fixtures voor common test data
- Mock OpenAI calls in tests

### Code Organization and Standards

**File Structure Approach**: 
- Nieuwe features in dedicated submodules
- Components folder voor herbruikbare UI delen
- Utils uitbreiden voor shared functionality

**Naming Conventions**: 
- snake_case voor files en functies
- PascalCase voor classes
- UPPER_CASE voor constants
- Nederlandse functienamen voor business logic

**Coding Standards**: 
- Type hints verplicht voor public functions
- Docstrings in Nederlands voor business logic
- Black formatter voor consistentie
- Import sorting met isort

**Documentation Standards**: 
- README per nieuwe module
- Inline comments voor complexe logica
- API documentatie voor nieuwe endpoints
- Changelog updates per feature

### Deployment and Operations

**Build Process Integration**: 
- Geen build process (Python interpreted)
- Requirements.txt voor dependencies
- Virtual environment aanbevolen

**Deployment Strategy**: 
- Manual deployment via streamlit run
- Geen CI/CD pipeline aanwezig
- Database migraties handmatig

**Monitoring and Logging**: 
- Structured logging naar logs/ folder
- Performance metrics in cache/
- Error tracking via try/except blocks

**Configuration Management**: 
- Consolideer naar single config system
- Environment variables voor secrets
- Config files voor applicatie settings

### Risk Assessment and Mitigation

**Technical Risks**: 
- Import path chaos kan builds breken
- Legacy code dependencies fragiel
- Test suite repair kan regressies introduceren

**Integration Risks**: 
- Services consolidatie kan edge cases missen
- UI state management tussen tabs complex
- Database locks bij concurrent access

**Deployment Risks**: 
- Geen rollback mechanisme
- Manual deployment error-prone
- Database corruptie mogelijk

**Mitigation Strategies**: 
- Stapsgewijze implementatie met manual testing
- Database backups voor elke major change
- Feature flags voor nieuwe functionaliteit
- Uitgebreide logging voor debugging

## Epic and Story Structure

### Epic Approach

**Epic Structure Decision**: Enkele comprehensive epic voor "Legacy Feature Restoration en UI Completeness" met rationale dat alle werk gerelateerd is aan het werkend maken van bestaande functionaliteit.

## Epic 1: Complete Legacy Feature Parity in Nieuwe Architectuur

**Epic Goal**: Alle functionaliteit die beschikbaar was in de legacy versie volledig werkend maken in de nieuwe modulaire architectuur met 100% UI tab functionaliteit.

**Integration Requirements**: 
- Behoud backward compatibility met bestaande data
- Gebruik UnifiedDefinitionService patterns
- Respecteer Streamlit session state management
- Test elke story met manual testing protocol

### Story 1.1: Database Concurrent Access & Encoding Fixes
Als een developer,
wil ik dat de database concurrent access ondersteunt zonder locks,
zodat meerdere gebruikers tegelijk kunnen werken.

#### Acceptance Criteria
1: SQLite WAL mode geïmplementeerd
2: Connection pooling werkend
3: UTF-8 encoding gefixt in web lookup
4: Geen database locks bij 5 concurrent users

#### Integration Verification
- IV1: Bestaande definities blijven toegankelijk
- IV2: Web lookup resultaten tonen Nederlandse karakters correct
- IV3: Performance degradeert niet (blijft <12 sec)

### Story 1.2: UI Quick Wins Implementation
Als een gebruiker,
wil ik de basis UI verbeteringen direct zien,
zodat de applicatie prettiger werkt.

#### Acceptance Criteria
1: Term input field op hoofdpagina werkt
2: Metadata velden zijn zichtbaar en actief
3: Session state persistence tussen page reloads
4: Widget key generator bug gefixt

#### Integration Verification
- IV1: Bestaande UI tabs blijven werken
- IV2: Geen regressie in werkende features
- IV3: Session data gaat niet verloren

### Story 1.3: Content Enrichment Service
Als een gebruiker,
wil ik synoniemen, antoniemen en toelichtingen zien,
zodat definities rijker en completer zijn.

#### Acceptance Criteria
1: ContentEnrichmentService geïmplementeerd
2: Legacy enrichment logic geport
3: UI toont alle enrichment data
4: Performance blijft <5 sec voor enrichment

#### Integration Verification
- IV1: Integratie met UnifiedDefinitionService
- IV2: Bestaande definities kunnen alsnog verrijkt worden
- IV3: Caching voorkomt dubbele API calls

### Story 1.4: Complete UI Tab Activation
Als een gebruiker,
wil ik alle 10 tabs kunnen gebruiken,
zodat alle functionaliteit beschikbaar is.

#### Acceptance Criteria
1: Alle 7 niet-werkende tabs geactiveerd
2: Prompt viewer met copy functie werkend
3: Aangepaste definitie editor functioneel
4: Developer tools showing logs

#### Integration Verification
- IV1: Tab navigatie blijft soepel
- IV2: Data wordt correct gedeeld tussen tabs
- IV3: Geen memory leaks bij tab switches

### Story 1.5: Prompt Optimization
Als een developer,
wil ik dat prompts kleiner en efficiënter zijn,
zodat de kosten lager zijn en response sneller.

#### Acceptance Criteria
1: Prompt size <10k characters (van 35k)
2: Dynamische prompt building
3: Context-aware prompt selection
4: Quality blijft gelijk via A/B testing

#### Integration Verification
- IV1: Definitie kwaliteit degradeert niet
- IV2: Alle toetsregels blijven werken
- IV3: Response tijd verbetert naar <5 sec

### Story 1.6: Test Suite Restoration
Als een developer,
wil ik een werkende test suite hebben,
zodat ik met vertrouwen kan ontwikkelen.

#### Acceptance Criteria
1: Import paths gestandaardiseerd
2: 60% test coverage bereikt
3: CI-friendly test execution
4: Test data fixtures beschikbaar

#### Integration Verification
- IV1: Legacy tests gemoderniseerd waar nodig
- IV2: Nieuwe features hebben tests
- IV3: Tests draaien in <5 minuten

## Checklist Results Report

*To be completed by architect-checklist execution*

## Next Steps

### Story Manager Handoff

Voor de Story Manager om verder te werken met deze brownfield enhancement:

- Referentie: Deze PRD met focus op legacy feature parity
- Eerste story: Database fixes (BLOCKER voor andere werk)
- Key requirement: Alle legacy features moeten werken
- Verificatie: Manual testing protocol voor elke story
- Constraint: Behoud backward compatibility

Prioriteit volgorde:
1. Database & encoding fixes (blockers)
2. UI quick wins (direct zichtbaar)
3. Content enrichment (core feature)
4. Complete UI activation
5. Performance optimization
6. Test suite (voor maintenance)

### Developer Handoff

Voor developers die beginnen met implementatie:

- Start met docs/brownfield-architecture.md voor context
- Volg UnifiedDefinitionService patterns
- Check legacy code in src/services/legacy/ voor specs
- Test manual eerst, automated tests zijn broken
- Commit kleine, werkende increments

Quick start:
```bash
cd /Users/chrislehnen/Projecten/Definitie-app
cp .env.example .env
# Add OpenAI key
pip install -r requirements.txt
streamlit run src/app.py
```