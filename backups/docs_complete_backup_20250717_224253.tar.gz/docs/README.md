# 📚 DefinitieAgent Documentatie

Welkom bij de documentatie van het DefinitieAgent project. Deze folder bevat alle technische en functionele documentatie.

## 🗂️ Documentatie Structuur

### 📋 Requirements & Planning
- **[ROADMAP.md](requirements/ROADMAP.md)** - 6-weken development roadmap
- **[BACKLOG.md](BACKLOG.md)** - Alle features, bugs en tasks
- **[PROJECT_STATUS.md](requirements/PROJECT_STATUS.md)** - Huidige project status

### 🏗️ Architectuur
- **[brownfield-architecture.md](brownfield-architecture.md)** - Actuele systeem architectuur
- **[development/architecture/](development/architecture/)** - Architectuur diagrammen

### 🔧 Technische Documentatie
- **[development/technical/](development/technical/)** - API specs, technische details
- **[ai-toetsing/](development/technical/ai-toetsing/)** - Validatie regels documentatie

### 📊 Analyses
- **[COMPLETE_CODEBASE_ANALYSIS.md](COMPLETE_CODEBASE_ANALYSIS.md)** - Grondige code analyse
- **[DEFINITIEAGENT_CODEBASE_ANALYSIS_2025.md](DEFINITIEAGENT_CODEBASE_ANALYSIS_2025.md)** - Recente analyse

### 🗄️ Archief
- **[requirements/archive_historical/](requirements/archive_historical/)** - Historische documentatie

## 🚀 Quick Links

Voor developers:
- [Setup Guide](../SETUP.md) - Hoe het project op te zetten
- [Contributing](../CONTRIBUTING.md) - Development guidelines
- [Coding Standards](../CLAUDE.md) - AI coding conventies

Voor gebruikers:
- [README.md](../README.md) - Project overzicht
- User Guide - *Coming soon*

## 📅 Laatste Updates

- **17 juli 2025** - Documentatie structuur gereorganiseerd
- **17 juli 2025** - Nieuwe 6-weken roadmap gecreëerd
- **17 juli 2025** - Backlog geconsolideerd (77+ items)

## 🔍 Zoeken

Als je iets specifieks zoekt:
1. Check eerst de actuele documenten hierboven
2. Gebruik je editor's search functie
3. Kijk in het archief voor historische context

---
*Deze documentatie wordt actief onderhouden. Voor vragen, zie de [project README](../README.md).*