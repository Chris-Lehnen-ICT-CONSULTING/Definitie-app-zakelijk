#!/usr/bin/env python3
"""Test de main Streamlit app direct."""

import subprocess
import time
import requests
import sys

def test_streamlit_app():
    """Start Streamlit app en test of deze draait."""
    print("🚀 Starting Streamlit app...")
    
    # Start de app in een subprocess
    process = subprocess.Popen(
        ["streamlit", "run", "src/main.py", "--server.headless", "true", "--server.port", "8505"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )
    
    # Geef app tijd om te starten
    print("⏳ Wachten tot app start...")
    time.sleep(5)
    
    # Check of process draait
    if process.poll() is not None:
        stdout, stderr = process.communicate()
        print("❌ App crashte direct!")
        print(f"STDOUT: {stdout}")
        print(f"STDERR: {stderr}")
        return False
    
    # Test of de app bereikbaar is
    try:
        response = requests.get("http://localhost:8505", timeout=5)
        if response.status_code == 200:
            print("✅ Streamlit app draait op http://localhost:8505")
            print(f"   Response size: {len(response.text)} bytes")
            
            # Check voor belangrijke UI elementen
            ui_elements = {
                "DefinitieAgent": "App titel",
                "Begrip": "Input veld",
                "Genereer": "Button"
            }
            
            for element, description in ui_elements.items():
                if element in response.text:
                    print(f"   ✅ {description} gevonden")
                else:
                    print(f"   ❌ {description} NIET gevonden")
            
            return True
        else:
            print(f"❌ App response code: {response.status_code}")
            return False
            
    except requests.exceptions.ConnectionError:
        print("❌ Kan geen verbinding maken met app")
        return False
    except Exception as e:
        print(f"❌ Fout bij testen: {e}")
        return False
    finally:
        # Stop de app
        print("\n🛑 Stopping app...")
        process.terminate()
        process.wait(timeout=5)
        print("✅ App gestopt")


if __name__ == "__main__":
    success = test_streamlit_app()
    sys.exit(0 if success else 1)