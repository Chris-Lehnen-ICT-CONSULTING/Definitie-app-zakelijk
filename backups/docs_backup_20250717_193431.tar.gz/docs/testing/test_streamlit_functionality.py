#!/usr/bin/env python3
"""
Functionele test voor de Streamlit DefinitieAgent applicatie.
Test alle hoofdfunctionaliteiten zonder UI interactie.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

import os
os.environ['OPENAI_API_KEY'] = os.getenv('OPENAI_API_KEY', '')

def test_main_components():
    """Test of alle hoofdcomponenten werken."""
    print("🔍 Testing hoofdcomponenten...")
    
    results = {}
    
    # Test 1: Config laden
    try:
        from config.config_loader import load_toetsregels, load_verboden_woorden
        toetsregels = load_toetsregels()
        verboden_woorden = load_verboden_woorden()
        
        results['config'] = {
            'status': 'success',
            'toetsregels_count': len(toetsregels),
            'verboden_woorden_count': len(verboden_woorden)
        }
        print(f"✅ Config geladen: {len(toetsregels)} toetsregels, {len(verboden_woorden)} verboden woorden")
    except Exception as e:
        results['config'] = {'status': 'error', 'error': str(e)}
        print(f"❌ Config laden mislukt: {e}")
    
    # Test 2: AI Toetser
    try:
        from ai_toetser.core import AIToetser
        toetser = AIToetser()
        
        # Test met simpele definitie
        test_definitie = "Een proces waarbij de identiteit van een persoon wordt vastgesteld"
        test_begrip = "authenticatie"
        
        resultaat = toetser.toets_definitie(test_definitie, test_begrip)
        
        results['ai_toetser'] = {
            'status': 'success',
            'test_passed': resultaat['voldoet'],
            'issues_found': len(resultaat.get('problemen', []))
        }
        print(f"✅ AI Toetser werkt: {'Voldoet' if resultaat['voldoet'] else 'Voldoet niet'}")
    except Exception as e:
        results['ai_toetser'] = {'status': 'error', 'error': str(e)}
        print(f"❌ AI Toetser mislukt: {e}")
    
    # Test 3: Definitie Generator (zonder API call)
    try:
        from generation.definitie_generator import DefinitieGenerator
        generator = DefinitieGenerator()
        
        # Test alleen initialisatie
        results['generator'] = {
            'status': 'success',
            'initialized': True
        }
        print("✅ Definitie Generator geïnitialiseerd")
    except Exception as e:
        results['generator'] = {'status': 'error', 'error': str(e)}
        print(f"❌ Generator initialisatie mislukt: {e}")
    
    # Test 4: Voorbeelden Generator
    try:
        from voorbeelden.voorbeelden_generator import VoorbeeldenGenerator
        voorbeelden_gen = VoorbeeldenGenerator()
        
        results['voorbeelden'] = {
            'status': 'success',
            'initialized': True
        }
        print("✅ Voorbeelden Generator geïnitialiseerd")
    except Exception as e:
        results['voorbeelden'] = {'status': 'error', 'error': str(e)}
        print(f"❌ Voorbeelden Generator mislukt: {e}")
    
    # Test 5: Export functionaliteit
    try:
        from export.txt_export import export_to_txt
        import tempfile
        
        # Test export met dummy data
        test_data = {
            'begrip': 'test',
            'definitie': 'test definitie',
            'metadata': {},
            'context_dict': {},
            'toetsresultaten': []
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as tmp:
            export_to_txt(test_data, tmp.name)
            file_exists = os.path.exists(tmp.name)
            os.unlink(tmp.name)
        
        results['export'] = {
            'status': 'success',
            'file_created': file_exists
        }
        print("✅ Export functionaliteit werkt")
    except Exception as e:
        results['export'] = {'status': 'error', 'error': str(e)}
        print(f"❌ Export mislukt: {e}")
    
    # Test 6: Database operaties
    try:
        from database.definitie_repository import DefinitieRepository, DefinitieRecord
        import tempfile
        
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            repo = DefinitieRepository(tmp.name)
            
            # Test CRUD
            record = DefinitieRecord(
                begrip="test_begrip",
                definitie="test definitie",
                categorie="proces",
                organisatorische_context="test",
                created_by="test_user"
            )
            
            # Create
            record_id = repo.create_definitie(record)
            
            # Read
            retrieved = repo.get_definitie_by_id(record_id)
            
            # Search
            search_results = repo.search_definities("test")
            
            os.unlink(tmp.name)
            
            results['database'] = {
                'status': 'success',
                'crud_works': True,
                'search_count': len(search_results)
            }
            print("✅ Database operaties werken")
    except Exception as e:
        results['database'] = {'status': 'error', 'error': str(e)}
        print(f"❌ Database operaties mislukt: {e}")
    
    return results


def test_services_integration():
    """Test de geïntegreerde services."""
    print("\n🔍 Testing service integratie...")
    
    try:
        from services.definition_service import DefinitionService
        from ui.session_state import SessionStateManager
        
        # Mock session state
        class MockSessionState:
            def __init__(self):
                self.data = {}
            
            def __getitem__(self, key):
                return self.data.get(key, "")
            
            def __setitem__(self, key, value):
                self.data[key] = value
            
            def get(self, key, default=None):
                return self.data.get(key, default)
        
        # Test service
        import streamlit as st
        st.session_state = MockSessionState()
        
        service = DefinitionService()
        print("✅ DefinitionService geïnitialiseerd")
        
        # Test session state manager
        SessionStateManager.initialize_session_state()
        print("✅ SessionStateManager werkt")
        
        return True
        
    except Exception as e:
        print(f"❌ Service integratie mislukt: {e}")
        return False


def test_prompt_builder():
    """Test prompt builder functionaliteit."""
    print("\n🔍 Testing prompt builder...")
    
    try:
        from prompt_builder.prompt_builder import PromptBuilder
        
        builder = PromptBuilder()
        
        # Test prompt generatie
        prompt = builder.build_prompt(
            begrip="authenticatie",
            context_organisatie="gemeente",
            context_afdeling="burgerzaken",
            extra_instructies=""
        )
        
        if prompt and len(prompt) > 100:
            print(f"✅ Prompt builder werkt (prompt lengte: {len(prompt)} chars)")
            return True
        else:
            print("❌ Prompt builder genereerde geen valide prompt")
            return False
            
    except Exception as e:
        print(f"❌ Prompt builder mislukt: {e}")
        return False


def test_opschoning():
    """Test tekst opschoning module."""
    print("\n🔍 Testing tekst opschoning...")
    
    try:
        from opschoning.tekst_opschoner import TekstOpschoner
        
        opschoner = TekstOpschoner()
        
        # Test opschoning
        test_tekst = "Dit is een test definitie met extra spaties  en \n newlines."
        schone_tekst = opschoner.schoon_definitie_op(test_tekst)
        
        if schone_tekst and len(schone_tekst) > 0:
            print(f"✅ Tekst opschoner werkt")
            print(f"   Origineel: {len(test_tekst)} chars")
            print(f"   Opgeschoond: {len(schone_tekst)} chars")
            return True
        else:
            print("❌ Tekst opschoner produceerde lege output")
            return False
            
    except Exception as e:
        print(f"❌ Tekst opschoner mislukt: {e}")
        return False


def run_all_functional_tests():
    """Voer alle functionele tests uit."""
    print("=" * 60)
    print("🚀 FUNCTIONELE TEST - STREAMLIT DEFINITIEAGENT")
    print("=" * 60)
    
    # Test hoofdcomponenten
    component_results = test_main_components()
    
    # Test integraties
    services_ok = test_services_integration()
    prompt_ok = test_prompt_builder()
    opschoning_ok = test_opschoning()
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 FUNCTIONELE TEST RESULTATEN")
    print("=" * 60)
    
    # Component results
    all_success = True
    for component, result in component_results.items():
        status = "✅" if result['status'] == 'success' else "❌"
        print(f"{status} {component.upper()}: {result['status']}")
        if result['status'] != 'success':
            all_success = False
            if 'error' in result:
                print(f"   Error: {result['error']}")
    
    # Integration results
    print(f"{'✅' if services_ok else '❌'} SERVICE INTEGRATIE")
    print(f"{'✅' if prompt_ok else '❌'} PROMPT BUILDER")
    print(f"{'✅' if opschoning_ok else '❌'} TEKST OPSCHONING")
    
    if not all([services_ok, prompt_ok, opschoning_ok]):
        all_success = False
    
    print("\n" + "=" * 60)
    if all_success:
        print("✅ ALLE FUNCTIONELE TESTS GESLAAGD!")
        print("\nDe applicatie is klaar voor gebruik via:")
        print("  streamlit run src/main.py")
    else:
        print("⚠️  ENKELE TESTS GEFAALD")
        print("\nDe applicatie kan problemen hebben met bepaalde functionaliteiten.")
    
    return all_success


if __name__ == "__main__":
    import dotenv
    dotenv.load_dotenv()
    
    success = run_all_functional_tests()
    sys.exit(0 if success else 1)