#!/usr/bin/env python3
"""
Uitgebreide test suite voor emergency fixes.
Test alle kritieke componenten na de fixes.
"""

import sys
import os
from pathlib import Path

# Voeg src directory toe aan Python path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

def test_imports():
    """Test of alle modules correct importeren."""
    print("🔍 Testing module imports...")
    
    errors = []
    modules_to_test = [
        # Core modules
        ("src.main", "Main application"),
        ("src.centrale_module_definitie_kwaliteit", "Legacy main module"),
        
        # Fixed modules
        ("src.web_lookup.definitie_lookup", "Web lookup - definities"),
        ("src.web_lookup.bron_lookup", "Web lookup - bronnen"),
        ("src.ui.session_state", "Session state manager"),
        ("src.database.definitie_repository", "Database repository"),
        
        # Other critical modules
        ("src.services.definition_service", "Definition service"),
        ("src.ai_toetser.core", "AI toetser"),
        ("src.generation.definitie_generator", "Definitie generator"),
        ("src.config.config_manager", "Config manager"),
    ]
    
    for module_name, description in modules_to_test:
        try:
            __import__(module_name)
            print(f"✅ {description}: {module_name}")
        except Exception as e:
            error_msg = f"❌ {description}: {module_name} - {str(e)}"
            print(error_msg)
            errors.append(error_msg)
    
    return len(errors) == 0, errors


def test_session_state_manager():
    """Test SessionStateManager functionaliteit."""
    print("\n🔍 Testing SessionStateManager...")
    
    try:
        from src.ui.session_state import SessionStateManager
        
        # Test clear_value method bestaat
        assert hasattr(SessionStateManager, 'clear_value'), "clear_value method missing"
        print("✅ clear_value method exists")
        
        # Test andere belangrijke methods
        methods = ['initialize_session_state', 'get_value', 'set_value', 
                  'update_definition_results', 'get_export_data']
        
        for method in methods:
            assert hasattr(SessionStateManager, method), f"{method} missing"
            print(f"✅ {method} exists")
            
        return True, []
        
    except Exception as e:
        error_msg = f"❌ SessionStateManager test failed: {str(e)}"
        print(error_msg)
        return False, [error_msg]


def test_database_operations():
    """Test database operaties met nieuwe connection pooling."""
    print("\n🔍 Testing Database Operations...")
    
    try:
        from src.database.definitie_repository import DefinitieRepository, DefinitieRecord
        import tempfile
        
        # Gebruik temp database voor test
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        repo = DefinitieRepository(db_path)
        print("✅ Database initialized")
        
        # Test create
        record = DefinitieRecord(
            begrip="test_begrip",
            definitie="test definitie",
            categorie="proces",
            organisatorische_context="test context"
        )
        
        record_id = repo.create_definitie(record)
        print(f"✅ Created record with ID: {record_id}")
        
        # Test read
        retrieved = repo.get_definitie_by_id(record_id)
        assert retrieved is not None, "Failed to retrieve record"
        assert retrieved.begrip == "test_begrip", "Retrieved data mismatch"
        print("✅ Retrieved record successfully")
        
        # Test search
        search_results = repo.search_definities("test")
        assert len(search_results) > 0, "Search returned no results"
        print(f"✅ Search found {len(search_results)} results")
        
        # Cleanup
        os.unlink(db_path)
        
        return True, []
        
    except Exception as e:
        error_msg = f"❌ Database test failed: {str(e)}"
        print(error_msg)
        return False, [error_msg]


def test_web_lookup():
    """Test web lookup modules na encoding fix."""
    print("\n🔍 Testing Web Lookup Modules...")
    
    try:
        from src.web_lookup.definitie_lookup import zoek_definitie
        from src.web_lookup.bron_lookup import zoek_bronnen_voor_begrip
        
        print("✅ Web lookup modules imported successfully")
        
        # Test functie signatures
        import inspect
        
        # Check zoek_definitie
        sig = inspect.signature(zoek_definitie)
        params = list(sig.parameters.keys())
        assert 'begrip' in params, "zoek_definitie missing 'begrip' parameter"
        print("✅ zoek_definitie function signature OK")
        
        # Check zoek_bronnen_voor_begrip  
        sig = inspect.signature(zoek_bronnen_voor_begrip)
        params = list(sig.parameters.keys())
        assert 'begrip' in params, "zoek_bronnen_voor_begrip missing 'begrip' parameter"
        print("✅ zoek_bronnen_voor_begrip function signature OK")
        
        return True, []
        
    except Exception as e:
        error_msg = f"❌ Web lookup test failed: {str(e)}"
        print(error_msg)
        return False, [error_msg]


def test_config_loading():
    """Test of config files correct laden."""
    print("\n🔍 Testing Config Loading...")
    
    try:
        from src.config.config_manager import ConfigManager
        
        config = ConfigManager()
        
        # Test toetsregels
        toetsregels = config.get_toetsregels()
        assert isinstance(toetsregels, list), "Toetsregels should be a list"
        assert len(toetsregels) > 0, "No toetsregels loaded"
        print(f"✅ Loaded {len(toetsregels)} toetsregels")
        
        # Test verboden woorden
        verboden = config.get_verboden_woorden()
        assert isinstance(verboden, list), "Verboden woorden should be a list"
        print(f"✅ Loaded {len(verboden)} verboden woorden")
        
        return True, []
        
    except Exception as e:
        error_msg = f"❌ Config loading test failed: {str(e)}"
        print(error_msg)
        return False, [error_msg]


def run_all_tests():
    """Voer alle tests uit en geef summary."""
    print("=" * 60)
    print("🚀 UITGEBREIDE TEST SUITE - EMERGENCY FIXES")
    print("=" * 60)
    
    all_errors = []
    test_results = []
    
    # Run all tests
    tests = [
        ("Module Imports", test_imports),
        ("SessionStateManager", test_session_state_manager),
        ("Database Operations", test_database_operations),
        ("Web Lookup", test_web_lookup),
        ("Config Loading", test_config_loading)
    ]
    
    for test_name, test_func in tests:
        success, errors = test_func()
        test_results.append((test_name, success))
        all_errors.extend(errors)
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 TEST SUMMARY")
    print("=" * 60)
    
    for test_name, success in test_results:
        status = "✅ PASSED" if success else "❌ FAILED"
        print(f"{test_name}: {status}")
    
    if all_errors:
        print("\n❌ ERRORS FOUND:")
        for error in all_errors:
            print(f"  - {error}")
    else:
        print("\n✅ ALL TESTS PASSED!")
    
    return len(all_errors) == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)