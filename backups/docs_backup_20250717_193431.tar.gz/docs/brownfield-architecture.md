# DefinitieAgent Brownfield Architecture Document

## Introduction

This document captures the CURRENT STATE of the DefinitieAgent codebase, including technical debt, workarounds, and real-world patterns. It serves as a reference for AI agents working on enhancements.

### Document Scope

Focused on areas relevant to: **Migrating all legacy functionalities to work properly in the new modular structure**

### Change Log

| Date | Version | Description | Author |
|------|---------|-------------|--------|
| 2025-07-17 | 1.0 | Initial brownfield analysis | BMad Orchestrator |

## Quick Reference - Key Files and Entry Points

### Critical Files for Understanding the System

- **Main Entry**: `src/app.py` - Streamlit application entry
- **Configuration**: `src/config/settings.py`, `src/config/ai_config.py`, `.env`
- **Core Business Logic**: `src/services/unified_definition_service.py`
- **API Definitions**: REST endpoints in Streamlit tabs (`src/tabs/`)
- **Database Models**: `src/models/` (Definition, ValidationResult, DocumentUpload)
- **Key Algorithms**: 
  - `src/ai_toetsing/toetsing_service.py` - AI validation orchestration
  - `src/services/definition_generation_service.py` - Core generation logic
  - `src/web_lookup/web_lookup_service.py` - External content enrichment

### Enhancement Impact Areas

Voor legacy → modern migratie zijn deze gebieden cruciaal:
- `src/services/` - Service consolidatie en nieuwe features
- `src/tabs/` - UI components voor ontbrekende functionaliteit
- `src/ai_agents/` - AI content enrichment (synoniemen, toelichting)
- `tests/` - Test suite modernisatie

## High Level Architecture

### Technical Summary

Een AI-powered Nederlandse definitie generator voor juridische/overheidscontexten in transitie van monolithisch naar modulair. Features-first ontwikkeling met pragmatische legacy integratie.

### Actual Tech Stack (from requirements.txt/pyproject.toml)

| Category | Technology | Version | Notes |
|----------|------------|---------|--------|
| Runtime | Python | 3.8+ | Compatibility constraint |
| Framework | Streamlit | 1.29.0 | UI framework |
| AI/ML | OpenAI | 1.12.0 | GPT-4 voor generatie |
| Database | SQLite | Built-in | Via SQLAlchemy |
| ORM | SQLAlchemy | 2.0.25 | Modern async support |
| HTTP | httpx | 0.26.0 | Async HTTP client |
| Validation | Pydantic | 2.5.3 | Data validation |

### Repository Structure Reality Check

- Type: Monorepo met module-based organisatie
- Package Manager: pip/poetry hybrid (requirements.txt primary)
- Notable: 4 verschillende config systemen, geen centrale config

## Source Tree and Module Organization

### Project Structure (Actual)

```text
definitie-app/
├── src/
│   ├── app.py              # Streamlit main entry
│   ├── services/           # Business logic (CONSOLIDATED!)
│   │   ├── unified_definition_service.py  # Nieuwe centrale service
│   │   ├── definition_generation_service.py  # Legacy wrapper
│   │   └── legacy/         # Oude code voor referentie
│   ├── ai_toetsing/        # 46 JSON validators + orchestration
│   ├── ai_agents/          # DEELS BROKEN - enrichment ontbreekt
│   ├── models/             # SQLAlchemy models
│   ├── repositories/       # Database access layer
│   ├── web_lookup/         # External content (encoding issues)
│   ├── tabs/               # 10 Streamlit UI tabs
│   └── utils/              # Helpers (veel duplicatie)
├── tests/                  # 87% broken tests
├── data/                   # SQLite DB + uploads
└── config/                 # 4 verschillende config systemen
```

### Key Modules and Their Purpose

- **Unified Definition Service**: `src/services/unified_definition_service.py` - Centrale orchestrator
- **AI Toetsing**: `src/ai_toetsing/toetsing_service.py` - 46 validators, JSON-based rules
- **Web Lookup**: `src/web_lookup/web_lookup_service.py` - BELANGRIJK: encoding issues
- **Legacy Services**: `src/services/legacy/` - NIET VERWIJDEREN - bevat ontbrekende features
- **Config Chaos**: 4 systemen - settings.py, ai_config.py, .env, config.json

## Data Models and APIs

### Data Models

In plaats van dupliceren, zie actuele model files:
- **Definition Model**: `src/models/definition.py` - Core definitie entiteit
- **ValidationResult Model**: `src/models/validation_result.py` - Toetsing resultaten
- **DocumentUpload Model**: `src/models/document_upload.py` - Document management
- **DTO's**: `src/models/dtos/` - Data transfer objects

### API Specifications

- **Streamlit "API"**: Via session state en UI callbacks
- **Internal API**: Service methodes met type hints
- **External**: OpenAI API, web scraping endpoints

## Technical Debt and Known Issues

### Critical Technical Debt

1. **Import Path Chaos**: 3 verschillende import stijlen door het project
   ```python
   # Style 1: Relative
   from ..services import DefinitionService
   # Style 2: Absolute from src
   from src.services import DefinitionService  
   # Style 3: Direct
   from services import DefinitionService
   ```

2. **Config Fragmentation**: 4 config systemen zonder centrale authority
   - `src/config/settings.py` - App settings
   - `src/config/ai_config.py` - AI parameters
   - `.env` - Environment vars
   - `config.json` - Legacy settings

3. **Test Suite Broken**: 87% tests failing door oude imports/API's

4. **Web Lookup Encoding**: Unicode/UTF-8 issues in `format_search_results()`

### Workarounds and Gotchas

- **Singleton Services**: UnifiedDefinitionService gebruikt get_instance() pattern
- **Session State**: Streamlit session state is de "database" voor UI state
- **Async in Sync**: Veel `asyncio.run()` calls door Streamlit limitaties
- **File Uploads**: Gaan naar temp folder, dan naar data/uploaded_documents/
- **Legacy Mode**: AUTO mode valt terug op legacy code die WERKT

## Integration Points and External Dependencies

### External Services

| Service | Purpose | Integration Type | Key Files |
|---------|---------|------------------|-----------|
| OpenAI | AI Generation | REST API | `src/services/ai_service.py` |
| Web Search | Content verrijking | Web scraping | `src/web_lookup/` |
| SQLite | Data persistence | Direct | `src/repositories/` |

### Internal Integration Points

- **Service Communication**: Via UnifiedDefinitionService singleton
- **UI ↔ Backend**: Streamlit session state als message bus
- **Legacy Integration**: Wrapper functions in service layer
- **Validation Pipeline**: JSON rules → Python validators → UI feedback

## Development and Deployment

### Local Development Setup

Werkende stappen (niet ideaal maar functioneel):

1. Clone repository
2. `pip install -r requirements.txt` (ignore warnings)
3. Copy `.env.example` to `.env`
4. Set OpenAI API key
5. `streamlit run src/app.py`

Known issues:
- Import errors? Run vanuit project root
- Database errors? Check data/ folder permissions
- UI glitches? Clear browser cache

### Build and Deployment Process

- **Development**: `streamlit run src/app.py`
- **Production**: Nog geen productie deployment
- **Database**: SQLite file in data/ (backup regelmatig!)

## Testing Reality

### Current Test Coverage

- Unit Tests: 14-40% coverage (meestal broken)
- Integration Tests: Enkele werkende voor rate limiting
- E2E Tests: Geen
- Manual Testing: PRIMARY methode

### Running Tests

```bash
# This will mostly fail
pytest tests/

# Werkende tests only
pytest tests/test_rate_limiter.py
pytest tests/ai_toetsing/test_toetsing_flow.py -k "validation"
```

## Enhancement Impact Analysis - Legacy to Modern Migration

### Files That Need Modification

Voor complete legacy functionaliteit herstel:

1. **Content Enrichment Service** (NIEUW)
   - Create: `src/services/content_enrichment_service.py`
   - Integrate: Update `unified_definition_service.py`
   - Port logic from: `src/services/legacy/definition_service.py`

2. **UI Components** (UITBREIDEN)
   - `src/tabs/definitie_generatie.py` - Add prompt viewer
   - `src/tabs/aangepaste_definitie.py` - Implement editing
   - `src/tabs/developer_tools.py` - Add debug panel

3. **Test Suite** (REPAREREN)
   - Fix all imports in `tests/`
   - Update API calls naar nieuwe service signatures
   - Add integration tests voor nieuwe features

### New Files/Modules Needed

```python
# Nieuwe structuur voor ontbrekende features
src/
├── services/
│   ├── content_enrichment_service.py  # Synoniemen, antoniemen, toelichting
│   └── orchestration_service.py       # Multi-agent coordinatie
├── components/
│   ├── prompt_viewer.py               # UI component voor prompts
│   ├── definition_editor.py           # Aangepaste definitie editing
│   └── developer_console.py           # Debug tools
└── utils/
    └── legacy_compat.py               # Legacy → Modern adapters
```

### Integration Considerations

- Nieuwe services moeten UnifiedDefinitionService pattern volgen
- UI components via Streamlit session state
- Behoud backward compatibility voor bestaande data
- Test coverage minimaal 60% voor nieuwe code

## Appendix - Useful Commands and Scripts

### Frequently Used Commands

```bash
# Development
streamlit run src/app.py

# Testing (what works)
pytest tests/test_rate_limiter.py -v
pytest tests/ai_toetsing/ -k "validation" -v

# Database
# Backup
cp data/definitions.db data/definitions.db.backup

# View data
sqlite3 data/definitions.db "SELECT * FROM definitions ORDER BY created_at DESC LIMIT 5;"

# Clear cache
rm -rf .streamlit/cache/
```

### Debugging and Troubleshooting

- **Logs**: Check terminal output (geen structured logging)
- **Debug Mode**: Set `DEBUG=True` in `.env`
- **Common Issues**: 
  - Import errors → Run from project root
  - Service not found → Check singleton initialization
  - UI state lost → Streamlit rerun issue

### Quick Implementation Guide

Voor AI agents die features implementeren:

1. **Check legacy code first**: `src/services/legacy/` heeft werkende implementaties
2. **Follow UnifiedDefinitionService pattern**: Singleton, async support
3. **Use existing validators**: `src/ai_toetsing/validators/` voor consistentie
4. **Test manually first**: Automated tests zijn onbetrouwbaar
5. **Document in code**: Nederlandse comments voor business logica