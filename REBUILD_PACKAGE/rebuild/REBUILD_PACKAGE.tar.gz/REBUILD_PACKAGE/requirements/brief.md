# Project Brief: V1 → V2 Complete Replacement Strategy

## Executive Summary

**V1 → V2 Complete Replacement**: Strategische migratie van DefinitieAgent's juridische definitie generatie van legacy sync orchestrator (V1) naar moderne 11-fase async orchestrator (V2). **Primair probleem**: Huidige dual-architecture creëert technische schuld en performance bottlenecks. **Target impact**: Juridische professionals die afhankelijk zijn van snelle, betrouwbare definitie generatie. **Key value proposition**: Eliminatie van legacy technical debt, 3-5x performance verbetering voor batch operaties, en unified modern architecture.

## Problem Statement

**Current State en Pain Points:**

**V1 Orchestrator Productie Context:**
- **"Nog niet live"** - DefinitieAgent is nog in development fase
- **V1 = Development baseline** - Huidige sync orchestrator als starting point
- **V2 = Target architecture** - Async 11-fase design als eindstaat

**Current State Pain Points:**
- **Dual Architecture Complexity**: V1 sync + V2 async exists maar V2 gebruikt legacy fallbacks
- **Technical Debt Accumulation**: V2 orchestrator valt terug op V1 mechanismen in plaats van native async
- **Prestaties Bottleneck**: Sync AI calls blokkeren async pipelines (AsyncGPTClient niet geïntegreerd)
- **Development Inefficiency**: Twee code paths onderhouden (V1 monolith + V2 structured flows)

**Impact van Problem (Development Stage):**
- **Engineering Velocity**: 40% meer development tijd door dual-path maintenance
- **Code Quality**: Technical debt compounds - V2 zou V1 afhankelijkheden moeten elimineren
- **Testen Complexity**: Dubbele test coverage needed voor sync + async paths
- **Future Scalability**: V1 sync architecture limiteert async performance benefits

**Waarom Existing Solutions Falen:**
- **Current State**: V2 "exists" maar gebruikt V1 als crutch (legacy fallbacks)
- **Hybrid Approach**: Maakt technical debt erger, niet beter
- **Gradual Migration**: Verlengt dual-maintenance periode onnodig

**Urgency - Pre-Production Window:**
- **Perfect Timing**: Voor go-live is ideal moment voor architectural consolidation
- **No User Disruption**: Geen production users = geen backward compatibility constraints
- **Clean Start**: V2 kan pure async zijn zonder V1 compatibility layers

**Business Problem Statement:**
*"We hebben een modern async architecture (V2) die nog steeds afhankelijk is van legacy sync code (V1), wat technical debt creëert en async performance benefits teniet doet. Als pre-production development team kunnen we nu kiezen: architectural purity (V2 only) vs complexity (dual maintenance). De window voor clean architecture sluit bij go-live."*

## Proposed Solution

**Core Concept en Approach:**

**"V1 Complete Elimination Strategy"** - Volledige deactivering van V1 orchestrator en afhankelijkheden, met V2 als single source of truth voor alle definitie generatie.

**Solution Components:**

1. **V2 Orchestrator Stabilization**
   - Remove all legacy fallback mechanisms (`_get_legacy_ai_service()`)
   - Implement native `AIServiceV2` bovenop `AsyncGPTClient`
   - Complete async pipeline zonder sync afhankelijkheden

2. **Legacy Code Removal**
   - Deactivate V1 orchestrator (`src/services/definition_orchestrator.py`)
   - Remove legacy functions (`stuur_prompt_naar_gpt()`)
   - Clean up dual-path routing in service container

3. **Architecture Consolidation**
   - Single async-only service architecture
   - Unified error handling (no sync/async hybrid patterns)
   - Streamlined testing approach (async-only test suites)

**Key Differentiators van Alternative Approaches:**

**vs Gradual Migration:**
- **No Dual Maintenance** - Eliminates ongoing technical debt accumulation
- **Clean Architecture** - Pure async design without compatibility layers
- **Pre-Production Advantage** - Leverage no-users window for clean transition

**vs Hybrid Approach:**
- **Prestaties Consistency** - All calls async, no sync bottlenecks
- **Code Clarity** - Single orchestrator, single pattern, single responsibility
- **Testen Simplicity** - Async-only test strategy, no dual-path coverage

**Waarom This Solution Succeeds:**

**Technical Success Factors:**
- **AsyncGPTClient Ready** - Proven async foundation already exists
- **V2 Architecture Superior** - 11-fase structured design vs monolithic V1
- **No User Impact** - Pre-production = perfect refactoring window

**Business Success Factors:**
- **Development Velocity** - Single codebase maintenance
- **Future Scalability** - Native async supports high-throughput scenarios
- **Code Quality** - Eliminates legacy technical debt before production

**High-Level Vision:**
*"DefinitieAgent launches with clean, modern, async-only architecture optimized for juridische professional workflows, with no legacy baggage holding back performance or maintainability."*

## Target Users

### Primary User Segment: Development Team

**Demographic Profile:**
- **Developers** - Software engineers working on DefinitieAgent
- **DevOps Engineers** - Uitrol and infrastructure team
- **QA Engineers** - Testen and quality assurance team

**Current Behaviors en Workflows:**
- **Dual-path Development** - Currently maintaining both V1 sync en V2 async code paths
- **Testen Complexity** - Running test suites for both orchestrator versions
- **Code Review Overhead** - Reviewing changes across multiple architectural patterns

**Specific Needs en Pain Points:**
- **Code Clarity** - Need single, consistent architectural pattern
- **Development Velocity** - Want to eliminate dual-maintenance overhead
- **Technical Debt Management** - Need clean codebase before production launch

**Goals They're Trying to Achieve:**
- Launch production-ready DefinitieAgent with modern architecture
- Minimize ongoing maintenance complexity
- Establish scalable foundation for future features

### Secondary User Segment: Future End Users (Juridische Professionals)

**Demographic Profile:**
- **Legal Professionals** - Advocaten, juristen, legal researchers
- **Prestaties-Sensitive Users** - Need fast, reliable definition generation

**Impact of V1 → V2 Decision:**
- **Prestaties Expectations** - Will experience either sync limitations (V1) or async benefits (V2)
- **System Reliability** - Will inherit either technical debt (hybrid) or clean architecture (V2-only)
- **Future Feature Capabilities** - V2-only enables advanced async features unavailable in V1

## Goals & Success Metrics

### Business Objectives

- **Eliminate Technical Debt**: Remove 100% of V1 orchestrator afhankelijkheden before production launch (Target: Complete by Sprint N+2)
- **Optimize Development Velocity**: Reduce codebase maintenance overhead by 40% through single-architecture approach (Measure: Story points per sprint)
- **Establish Prestaties Foundation**: Achieve 3-5x throughput improvement for batch operations via native async architecture (Measure: Requests/second benchmarks)
- **Ensure Production Readiness**: Launch with unified, modern architecture supporting juridische professional workflows (Target: Zero legacy fallbacks in production)

### User Success Metrics

- **Development Team Productivity**: 40% reduction in cross-orchestrator code review time and testing cycles
- **Code Quality Metrics**: Zero dual-path complexity, single async pattern consistency across codebase
- **Future Feature Velocity**: Async-only architecture enables advanced features (bulk processing, real-time updates) unavailable in V1
- **System Reliability**: Unified error handling and monitoring (no sync/async hybrid inconsistencies)

### Key Prestaties Indicators (KPIs)

- **Development Efficiency**: Story completion rate increases 35% after V1 elimination vs dual-maintenance baseline
- **Code Maintainability**: Cyclomatic complexity reduction of 25% through single-orchestrator architecture
- **Prestaties Baseline**: V2-only system achieves <200ms p95 response time for single definitions, <5s for batch operations
- **Production Readiness Score**: 100% async pipeline coverage, zero legacy afhankelijkheden at launch
- **Technical Debt Ratio**: 0% V1 code remaining in production codebase vs current ~45% V1/V2 hybrid

## MVP Scope

### Core Features (Must Have)

- **V2 Orchestrator Native Implementatie**: Complete AIServiceV2 integration with AsyncGPTClient - eliminates legacy fallbacks, enables true async AI calls
- **V1 Code Deactivation**: Full removal of V1 orchestrator from service container routing - no dual-path execution, single async architecture
- **Legacy Function Cleanup**: Deprecate and remove `stuur_prompt_naar_gpt()` and related sync compatibility layers - clean break from legacy patterns
- **Unified Error Handling**: Single async-only error taxonomy - consistent AIServiceError wrapping of OpenAI exceptions across entire system
- **Prestaties Validation**: Benchmarking suite proving V2 meets/exceeds V1 performance baselines - especially single request latency parity

### Out of Scope for MVP

- V1 Orchestrator backward compatibility layers
- Gradual migration tooling or dual-mode support
- Legacy sync API endpoint preservation
- V1 code archaeological cleanup (keep for reference if needed)
- Advanced async features beyond basic V2 orchestrator functionality
- Prestaties optimizations beyond AsyncGPTClient integration

### MVP Success Criteria

**MVP Success Definition**: *"DefinitieAgent development environment runs exclusively on V2 orchestrator with zero V1 afhankelijkheden, achieving equivalent or better performance than V1 baseline, with clean async-only architecture ready for production deployment."*

**Concrete Success Indicators:**
- All definition generation requests route through V2 orchestrator only
- Zero legacy fallback code paths executing in test suites
- V2 single-request performance ≥ V1 baseline (target: <200ms p95)
- Async batch operations demonstrate 3x+ throughput improvement
- Codebase complexity metrics show reduction vs hybrid state

## Post-MVP Vision

### Phase 2 Features

**Advanced Async Capabilities** (Enabled by V2-only architecture):
- **Real-time Definition Streaming**: Progressive definition generation with WebSocket updates
- **Bulk Processing Optimization**: Parallel batch jobs for large document processing
- **Advanced Caching Strategies**: Async-native cache warming and intelligent pre-fetching

**AsyncGPTClient Enhancements**:
- **Per-call Token Usage Tracking**: Replace heuristic counting with actual OpenAI usage data
- **Dynamic Rate Limiting**: Smart throttling based on API quota and usage patterns
- **Advanced Error Recovery**: Intelligent retry strategies with exponential backoff refinements

### Long-term Vision (1-2 Year)

**Production-Scale Architecture**:
- **Microservices Evolution**: V2 orchestrator as foundation for service decomposition
- **Multi-model AI Support**: Extend beyond OpenAI to Claude, Gemini, local models via unified async interface
- **Enterprise Integration**: V2's async foundation enables complex workflow orchestration

**Prestaties & Scalability**:
- **Horizontal Scaling**: V2 async architecture supports distributed processing
- **Advanced Monitoring**: Comprehensive async pipeline observability
- **Cost Optimization**: Fine-tuned AI service usage based on clean async telemetry

### Expansion Opportunities

**Market Expansion**:
- **International Markets**: V2's async architecture better supports multi-language, multi-jurisdiction processing
- **API Platform**: Clean async architecture as foundation for external developer API

**Product Evolution**:
- **AI-Powered Workflows**: V2's structured 11-fase design enables advanced legal workflow automation
- **Real-time Collaboration**: Async foundation supports collaborative definition editing
- **Integration Ecosystem**: V2 enables seamless integration with legal practice management systems

**Technology Leadership**:
- **Open Source Components**: AsyncGPTClient and V2 orchestrator patterns as community contributions
- **Industry Best Practices**: V2 architecture as reference implementation for legal tech async patterns

## Technical Considerations

### Platform Vereisten

- **Target Platforms**: Python-based backend service, async-first architecture
- **Runtime Support**: Python 3.8+, AsyncIO event loop, FastAPI framework compatibility
- **Prestaties Vereisten**: <200ms p95 single requests, >3x batch throughput vs V1, concurrent request handling via AsyncGPTClient semaphore limits

### Technology Preferences

- **AI Service Layer**: AsyncGPTClient as foundation (proven rate limiting, caching, retry logic)
- **Orchestration**: V2's 11-fase structured async pipeline vs V1 monolithic approach
- **Error Handling**: Unified AIServiceError taxonomy (wrap OpenAI exceptions for consistency)
- **Configuration**: Centralized via config_manager (eliminate AsyncGPTClient's separate RateLimitConfig)

### Architecture Considerations

- **Repository Structure**: Clean separation - V1 orchestrator marked deprecated/removed, V2 as primary service
- **Service Architecture**: Single async orchestrator with AIServiceV2 → AsyncGPTClient afhankelijkheid chain
- **Integration Vereisten**:
  - Service container wiring: V2 orchestrator gets AIServiceV2 instead of None/legacy fallback
  - Cache consistency: AsyncGPTClient uses same cache keys as legacy AI service
  - Thread safety: Handle sync cache calls in async context via thread pool
- **Beveiliging/Compliance**: Maintain existing DPIA/AVG compliance, GVI Rode Kabel integration patterns from V2

### V1 Removal Considerations

**Legacy Code Elimination**:
- **Service Container**: Remove V1 orchestrator factory, V2 becomes default
- **API Routing**: All definition endpoints route to V2 only
- **Testen**: Eliminate dual-path test coverage, async-only test suites

**Migration Technical Debt**:
- **Cache Migration**: Ensure AsyncGPTClient cache keys compatible with existing cached definitions
- **Configuration Migration**: Merge V1 AI service configs into unified config_manager approach
- **Error Handling Migration**: Replace sync AIServiceError patterns with async equivalents

## Constraints & Assumptions

### Constraints

- **Budget**: Internal refactoring project - no external costs beyond existing OpenAI API usage
- **Timeline**: Must complete before production launch - estimated 2-3 sprint window for V1 elimination
- **Resources**: Current development team capacity - no additional hiring needed for V1 removal
- **Technical**:
  - AsyncGPTClient current limitations (token heuristics, sync cache calls)
  - V2 orchestrator stability must be proven before V1 removal
  - Existing OpenAI API rate limits and usage patterns

### Key Assumptions

- **V2 Orchestrator Stability**: Current V2 implementation is production-ready with legacy fallbacks removed
- **AsyncGPTClient Reliability**: Existing async client handles production load without regression vs sync calls
- **Prestaties Parity**: V2 + AIServiceV2 achieves equivalent single-request performance to V1 baseline
- **Cache Compatibility**: AsyncGPTClient can use existing cache keys without data migration issues
- **No User Impact**: Pre-production status means no backward compatibility vereistes
- **Development Team Alignment**: Team agrees V1 elimination is preferable to dual-maintenance
- **Testen Coverage**: Current V2 test suite is comprehensive enough to replace V1 test coverage
- **Configuration Migration**: Existing AI service configurations can be successfully merged into unified approach

### Critical Success Afhankelijkheden

- **Technical Validation**: V2 performance benchmarking must confirm assumptions before V1 removal
- **Stability Proof**: V2 orchestrator must demonstrate reliable operation under expected load
- **Rollback Capability**: Ability to restore V1 temporarily if V2 proves unstable post-removal

## Risks & Open Questions

### Key Risks

- **V2 Prestaties Regression**: V2 orchestrator with AIServiceV2 performs worse than V1 baseline, impacting user experience when launched
- **AsyncGPTClient Stability Issues**: Hidden concurrency bugs or rate limiting failures under production load that weren't apparent with legacy fallbacks
- **Cache Inconsistency**: AsyncGPTClient cache keys conflict with legacy cache, causing corrupt or stale definition responses
- **Rollback Complexity**: If V1 removal causes critical issues, restoring V1 orchestrator may require significant re-integration effort
- **Token Counting Inaccuracy**: Heuristic token estimation (70-85% accuracy) causes budget overruns or unexpected API limiting
- **Development Timeline Pressure**: V1 removal takes longer than expected, delaying production launch timeline
- **Testen Gap**: V2-only architecture reveals edge cases not covered by current test suite

### Open Questions

- How will we handle emergency rollback if V2 proves unstable post-V1 removal?
- What's the exact performance difference between V1 sync calls and V2 + AsyncGPTClient under realistic load?
- Are there V1-specific features or error handling patterns that V2 doesn't replicate?
- How do we ensure AsyncGPTClient's sync cache calls don't cause blocking I/O issues in production?
- What monitoring and alerting do we need to detect V2 performance issues early?
- Should we keep V1 code in repository for reference/rollback, or completely remove it?
- How do we validate that all V1 code paths are truly eliminated from the codebase?

### Areas Needing Further Research

- **V2 Load Testen**: Comprehensive performance benchmarking under simulated production scenarios
- **AsyncGPTClient Concurrency Testen**: Thread safety validation under high concurrent request load
- **Cache Migration Strategy**: Detailed plan for AsyncGPTClient cache key compatibility
- **Error Handling Coverage**: Mapping of V1 error scenarios to V2 equivalents
- **Rollback Procedure**: Step-by-step V1 restoration process if needed
- **Production Monitoring**: Observability strategy for V2-only architecture
- **Token Usage Analysis**: Comparison of heuristic vs actual usage patterns to validate accuracy assumptions

## Next Steps

### Immediate Actions

1. **Technical Validation Sprint**: Architect review of V2 orchestrator stability and AsyncGPTClient production readiness
2. **Prestaties Benchmarking**: Execute comprehensive V1 vs V2 performance comparison under realistic load scenarios
3. **Risk Mitigation Planning**: Develop detailed rollback procedures and emergency V1 restoration capability
4. **Team Alignment Session**: Development team consensus building on V1 elimination approach and timeline
5. **Vereisten Documentation Update**: PM to revise PRD removing V1 compatibility vereistes, adding V2-only specifications

### Architect Handoff

**Strategic Analysis Complete** - This Project Brief provides comprehensive business case for V1 → V2 complete replacement strategy.

**Key Business Findings:**
- **Pre-production window** creates ideal opportunity for clean architectural transition
- **Technical debt elimination** outweighs gradual migration benefits given no-users constraint
- **Prestaties gains** (3-5x batch, async-only architecture) justify replacement approach
- **Development velocity** improvements through single-codebase maintenance

**Architect Review Required:**
- **Technical feasibility** of V2-only architecture
- **Prestaties validation** strategy and benchmarking approach
- **AsyncGPTClient production readiness** assessment
- **Rollback complexity** and mitigation strategies
- **Implementatie roadmap** refinement

**Critical Technical Questions for Architect:**
1. Is V2 orchestrator stable enough for production without V1 fallback?
2. What specific technical risks does V1 removal create?
3. How do we ensure AsyncGPTClient performance parity with legacy AI service?
4. What's the optimal implementation sequence for V1 elimination?

**Post-Architect Next Phase**: PM vereistes update incorporating technical feasibility findings and refined implementation strategy.

---

*Project Brief Created: 28-08-2025*
*Strategic Analysis: V1 → V2 Complete Replacement*
*Author: Mary - Business Analyst*
